<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Record Recovery</title>
    <link rel = "icon" type = "image/x-icon" href = "https://github.com/Zimvo-MazIV/Ctrl-Alt-404/blob/main/delete_favicon.jpeg?raw=true">
</head>
<body>
<!--Efforts to confrim a deletion before continuing -->
<!--Recovery handleR-->
    <?php
    include 'database_connection_personal.php';
    $anID = $_POST['anID'];

    $sql_re = "INSERT INTO animal SELECT * FROM deleted_arecord WHERE animalID = '$anID'";
    $result_re = $conn->query($sql_re);
    //REMEMBER TO DELETE THIS RECORD FROM THE DELETED TABLE

    //then ensure that the record really was deleted (ie; not in animals and exists in deleted)

    if($result_re){
        if($conn -> affected_rows > 0){
            echo "Record '$anID' Recovered!";
            //MAYBE SHOW THE RECOVERED ANIMAL DETAILS
        }else{
            echo "This record either is not deleted or is lost.";
            //after we recover you, you are now deleted from the deleted records table
            $sql_del = "DELETE from deleted_arecord where WHERE animalID = '$anID'";
            $res_del = query($sql_del);
        }
    }else{
        echo "Cannot recover a record that was not deleted.";
        echo "Unexpected Behaiviour, please contact tech team for assistance.";
    }
    $conn->close();
    ?>
    </body>
</html>
