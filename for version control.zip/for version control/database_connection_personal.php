<?php
//establish database connection 
$servername = "is3-dev.ict.ru.ac.za"; //IP address
$user = "CtrlAlt404";
$password = "Ctrl@lt404";
$database = "ctrlalt404";

$conn = mysqli_connect($servername, $user, $password, $database);
//$time = date("d/m/Y H:i:s", strtotime("now"));


if(!$conn){ //if the connection has failed due to most likely the defined above
    die(" " . mysqli_connect_error()); //die with the following message (error message basicalyy)
}else {
    //echo "Connection success by $user"; //to show that the connection was a success, and also this is to be deleted after.
    //echo "<br>";
}

?>