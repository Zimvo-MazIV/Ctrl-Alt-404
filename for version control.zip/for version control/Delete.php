<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Animal</title>
    <link rel = "icon" type = "image/x-icon" href = "https://github.com/Zimvo-MazIV/Ctrl-Alt-404/blob/main/delete_favicon.jpeg?raw=true">
    <!--CSS-->
    <style>
        body{
            background-color:#F6F6F6 ;
        }
        h1{
            color: #FF6700 ;
        }
        #l1{
            color: #002E4D ;
        }
    </style>
</head>
<body>
    <!--Form for which aninam to delete-->
    <h1>Record Deletion And Recovery</h1>
    <h3>Delete Animal Record</h3>
    <form name = "delete_form" action = "Delete1.php" method = "POST" onsubmit = "return confirmDel();">
        <label for = "anID" name = "anID" id = "l1"> <p1>Enter Dog Id: </p1></label>
        <input type = "number" size="3em" name = "anID" required> <br>
        <button type = "submit">Delete Animal Record</button>
    </form>
    <br>
    <br>
    <h3>Recover Animal Record</h3>
    <form name = "recover_form" action = "Recover.php" method = "POST" onsubmit = "return confirmRec();">
        <label for = "anID" name = "anID" id = "l1"> <p1>Enter Dog Id: </p1></label>
        <input type = "number" size="3em" name = "anID" required> <br>
        <button type = "submit">Recover Animal Record</button>
    </form>

   <script>
    function confirmDel(){
        return confirm("Are you sure you want to delete this item? This action may not be undone");
    }
    function confirmRec(){
        return confirm("Are you sure you wish to recover this dog?");
    }
    </script>

    <!--Try showing user the dog they are about to delete and have them confirm (either here or on the next page)-->

</body>
<?php



?>
</html>

