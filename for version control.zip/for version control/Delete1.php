<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Animal</title>
    <link rel = "icon" type = "image/x-icon" href = "https://github.com/Zimvo-MazIV/Ctrl-Alt-404/blob/main/delete_favicon.jpeg?raw=true">
</head>
<body>
<!--Efforts to confrim a deletion before continuing -->
<!--delete handleR-->
    <?php
    include 'database_connection_personal.php';
    $anID = $_POST['anID'];
    
    //SQL//////////////////////////////////////////////////
    //first move it:
    $sql_move = "INSERT INTO deleted_arecord SELECT * FROM animal WHERE animalID = '$anID'";
    $result1 = $conn->query($sql_move);
    //then delete it
    $sql = "DELETE FROM animal WHERE animalID = '$anID'";
    $result = $conn->query($sql);
 
if ($result){ //if the query is valid then...
    if($conn -> affected_rows > 0){ //if any rows were affected it means the dellete occured
        echo "Record with ID number '$anID' was successfully deleted.";
    }else{
        echo "No record '$anID' was found .";
    }
}else{
        echo "Unexpected Behaiviour, please contact tech team for assistance.";
    }
    $conn->close();
    //////SQL closed//////////////////////////////////////
    ?>

<!--SHOW THE DELETED ANIMAL AND OPTION TO REINSTATE THE DELETED ANIMAL-->
    
</body>
</html>