<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Animal</title>
    <link rel = "icon" type = "image/x-icon" href = "https://github.com/Zimvo-MazIV/Ctrl-Alt-404/blob/main/delete_favicon.jpeg?raw=true">
</head>
<body>
    <?php
    include 'database_connection_personal.php';
    $didnum = $_POST['didnum'];
    
    //SQL//////////////////////////////////////////////////
    $sql = "DELETE FROM dogsrecords WHERE didnum = '$didnum'";
    $result = $conn->query($sql);
 
if ($result){ //if the query is valid then...
    if($conn -> affected_rows > 0){ //if any rows were affected it means the dellete occured
        echo "Record with ID number '$didnum' was successfully deleted.";
    }else{
        echo "No record '$didnum' was found .";
    }
}else{
        echo "Unexpected Behaiviour, please contact tech team for assistance.";
    }
    $conn->close();
    //////SQL closed//////////////////////////////////////
    ?>

<!--SHOW THE DELETED ANIMAL AND REINSTATE THE DELETED ANIMAL-->
    
</body>
</html>