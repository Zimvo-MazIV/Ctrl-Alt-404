<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Animal</title>
    <link rel = "icon" type = "image/x-icon" href = "https://github.com/Zimvo-MazIV/Ctrl-Alt-404/blob/main/delete_favicon.jpeg?raw=true">
    <!--CSS-->
    <style>
        body{
            background-color:#F6F6F6 ;
        }
        h1{
            color: #FF6700 ;
        }
        #l1{
            color: #002E4D ;
        }
    </style>
</head>
<body>
    <!--Form for which aninam to delete-->
    <h1>Delete Animal Record</h1>
    <form name = "delete_form" action = "Delete1.php" method = "POST">
        <label for = "did" name = "label 1" id = "l1"> <p1>Enter Dog Id: </p1></label>
        <input type = "number" size="3em" name = "didnum" required> <br>
        <input type = "submit" value = "Delete" >
    </form>
   

    <!--Try showing user the dog they are about to delete and have them confirm (either here or on the next page)-->

</body>
<?php



?>
</html>